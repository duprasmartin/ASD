/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
NewerGainWithSliderAudioProcessorEditor::NewerGainWithSliderAudioProcessorEditor (NewerGainWithSliderAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 300);
    
    auto& params = processor.getParameters(); // get the parameters now...
    AudioParameterFloat* gainParameter = (AudioParameterFloat*) params.getUnchecked(0); // and put them in *gainParameter
    mGainParameterSlider.setRange(gainParameter->range.start, gainParameter->range.end); // and use those to set slider range
    mGainParameterSlider.setValue(*gainParameter);
    mGainParameterSlider.setBounds(0,0,240,135);
    mGainParameterSlider.setTextBoxStyle(Slider::NoTextBox, 1,0,0);
    mGainParameterSlider.addListener(this);
    //mGainParameterSlider.setMinAndMaxValues((double)0.0f, (double)1.0f); //<-- this makes the plugin CRASH! Bad, bad code. Sad!
    addAndMakeVisible(mGainParameterSlider);
}

NewerGainWithSliderAudioProcessorEditor::~NewerGainWithSliderAudioProcessorEditor()
{
}

//==============================================================================
void NewerGainWithSliderAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));

    g.setColour (Colours::white);
    g.setFont (15.0f);
    g.drawFittedText ("Hello World!", getLocalBounds(), Justification::centred, 1);
}

void NewerGainWithSliderAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
}

void NewerGainWithSliderAudioProcessorEditor::sliderValueChanged(Slider* slider)
{
    auto& params = processor.getParameters(); // this is storing not a pointer to but the *actual* address of the thing
    
    if (slider == &mGainParameterSlider)
    {
        //weird stuff ahead:
        //getUnchecked is accessing the 0th element, same as with an array; unchecked is really fast
        // (which we need for audio) at the expense of not checking if the data is safe
        AudioParameterFloat* gainParameter = (AudioParameterFloat*)params.getUnchecked(0);
        *gainParameter = mGainParameterSlider.getValue();
        //DBG("Slider value changed");
    
            }
}
