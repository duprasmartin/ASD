# NewerGainWithSlider
