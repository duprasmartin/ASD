/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
NewerGainWithSliderAudioProcessorEditor::NewerGainWithSliderAudioProcessorEditor (NewerGainWithSliderAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (400, 300);
    
    mGainParameterSlider.setBounds(0,0,240,135);
    mGainParameterSlider.setTextBoxStyle(Slider::NoTextBox, 1,0,0);
    mGainParameterSlider.addListener(this);
    //mGainParameterSlider.setMinAndMaxValues((double)0.0f, (double)1.0f); //<-- this makes the plugin CRASH! Bad, bad code. Sad!
    addAndMakeVisible(mGainParameterSlider);
}

NewerGainWithSliderAudioProcessorEditor::~NewerGainWithSliderAudioProcessorEditor()
{
}

//==============================================================================
void NewerGainWithSliderAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));

    g.setColour (Colours::white);
    g.setFont (15.0f);
    g.drawFittedText ("Hello World!", getLocalBounds(), Justification::centred, 1);
}

void NewerGainWithSliderAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
}

void NewerGainWithSliderAudioProcessorEditor::sliderValueChanged(Slider* slider)
{
    DBG("Hello");
}
